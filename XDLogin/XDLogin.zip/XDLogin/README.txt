Got Eggplant - Grocery list application

CMPE 137: Swift Programming for Mobile Devices

Project members:
Thinh Le, #010641462, timothyle85@gmail.com
Cherie Sew, #010108800, cheriemeiyee@gmail.com
David Tran, #009962771, dtran0419@gmail.com
Timothy Wu, #008867170, msgtimwu@gmail.com

Current Status:
- Developed homepage, login, signup, and logout functions
- Firebase used for login/signup/user account accessibility
- Placeholders for facebook and google logins via XD (may be removed or implemented with firebase in future submissions)